criaCartao(
    'Programação',
    'O que algoritmo?',
    'algoritmos são sequências finitas de instruções'
)

criaCartao(
    'Geografia',
    'Qual a capital de São Paulo?',
    'A capital da São Paulo é São Paulo'
)

criaCartao(
    'Programação',
    'O que é uma função?',
    'Uma função é um bloco de código que executa alguma tarefa'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz até mais em Inglês?',
    'Oi em ingles é until later'
)